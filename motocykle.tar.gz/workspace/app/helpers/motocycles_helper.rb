module MotocyclesHelper
end
