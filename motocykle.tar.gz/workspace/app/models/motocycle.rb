class Motocycle < ActiveRecord::Base
end
